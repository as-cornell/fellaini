This is Pattern Lab's default images directory. Images that only apply to the Pattern Lab instance should be placed here. e.g. One image of each dimension (portrait, landscape, square, etc.) to demonstrate the various components with images.

We recommend putting theme images into the theme's root-level `/images` directory or into a relevant component directory.
